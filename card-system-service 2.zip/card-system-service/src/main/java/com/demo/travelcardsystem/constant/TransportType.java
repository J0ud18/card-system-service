package com.demo.travelcardsystem.constant;

public enum TransportType {
    TRAIN,
    BUS
}
