package com.demo.travelcardsystem.exception;

public class InvalidCardException extends TravelCardException{
    public InvalidCardException(String msg) {
        super(msg);
    }

}
