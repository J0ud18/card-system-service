package com.demo.travelcardsystem.exception;

public class InvalidRechargeAmount extends TravelCardException{
    public InvalidRechargeAmount(String message) {
        super(message);
    }
}
